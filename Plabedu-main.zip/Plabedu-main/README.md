# ![Logo](https://github.com/GovernIB/maven/raw/binaris/portafib/projectinfo_Attachments/icon.jpg) plabedu (plabedu)
 *plabedu de les Illes Balears*

***Versions***

> - Versió Estable: Tag [__plabedu-1.0.1__](RELATIVE URL TO TAG) (branca [plabedu-1.1](RELATIVE URL TO BRANCH))<br/>
> - Versió en Desenvolupament: __plabedu-1.0.1__ (branca [plabedu-1.0](../../tree/plabedu-1.0))


***Documentació***

Nom | Descripció | Enllaç
------------ | ------------- | -------------
(CAT) Document d'Anàlisi i Disseny.odt | Document d'Anàlisi i Disseny | [Document](./doc/(CAT)%20Document%20d%27An&agrave;lisi%20i %20Disseny.odt)
(CAT) Manual d'Integració de Serveis REST.odt | Manual d'Integració de Serveis REST | [Document](./doc/(CAT)%20Manual%20d%27Integració%20de%20Serveis%20REST.odt)
(CAT) Manual d'Usuari.odt | Manual d'Usuari | [Document](./doc/(CAT)%20Manual%20d%27Usuari.odt)
(CAT) Manual de Migració de Versions.odt | Manual de Migraci&ograve; de Versions | [Document](./doc/(CAT)%20Manual%20de%20Migraci&ograve;%20de%20Versions.odt)
(CAT) Manual del Desenvolupador.odt | Manual del Desenvolupador | [Document](./doc/(CAT)%20Manual%20del%20Desenvolupador.odt)
(CAT) Manual Instal.lació.odt | Manual Instal.lació | [Document](./doc/(CAT)%20Manual%20Instal.lació.odt)


***Descripció***

FALTA una descripció resum del que fa plabedu

