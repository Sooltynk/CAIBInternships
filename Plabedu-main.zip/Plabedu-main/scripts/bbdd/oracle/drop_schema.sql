
    drop table PLE_PROCEDIMENT cascade constraints;

    drop table PLE_UNITATORGANICA cascade constraints;

    drop sequence PLE_PROCEDIMENT_SEQ;

    drop sequence PLE_UNITATORGANICA_SEQ;
