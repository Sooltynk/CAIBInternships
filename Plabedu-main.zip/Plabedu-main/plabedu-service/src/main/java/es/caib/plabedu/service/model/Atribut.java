package es.caib.plabedu.service.model;

/**
 * Representa atributs dels DTO. Camps que es poden emprar per filtrar o ordenar.
 */
public interface Atribut {

}
